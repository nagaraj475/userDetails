import { Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(public http: HttpClient) { }

  getUserDetails():Observable<any> { //Todo create a interface for userdeatils
    try {
      return this.http.get('https://jsonplaceholder.typicode.com/users').pipe(map(res =>res));
    } catch (error) {
      throw(error);
    }
  }

}

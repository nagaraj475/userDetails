import { Component } from '@angular/core';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(public userService : UserService){
    
  }
  userDetails: any; //Todo create a interface for userdeatils
  tempUserDetails: any;
  searchItem: string ='';
  noUserMsg: boolean = false;
  editForm: boolean = false;
  ngOnInit(){
    this.userService.getUserDetails().subscribe(data=>{
      this.userDetails = data;
      this.tempUserDetails = data;
    });
  }
  searchUsers(){
    this.noUserMsg = false;
    if(this.searchItem.length > 2){
      this.userDetails = this.userDetails.filter((x: { name: string; }) => x.name.toUpperCase().includes(this.searchItem.toUpperCase( )));
      if(this.userDetails.length == 0){
        this.noUserMsg = true;
      }
    } else {
      this.userDetails = this.tempUserDetails;
    }
  }
}
